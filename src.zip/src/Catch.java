import lejos.nxt.Button;
import lejos.nxt.Sound;
import lejos.robotics.Color;
import lejos.robotics.navigation.DifferentialPilot;


public class Catch {

	
	public  void alignToNearestObject(Data data) {
		float min=Float.MAX_VALUE;
		int deg = 45;
		float curr;
		boolean found = false;
		DifferentialPilot pilot = data.getPilot();
		
		// look around and get min distance
		pilot.rotate(deg, true);
		while(pilot.isMoving()){
			curr = data.getUs().getRange();
			min=Math.min(min, curr);
			System.out.println("min: " + min);
			Color t = data.getCs1().getColor();
			if(getRealColor(t) !=-1)
				return;
		}
		pilot.rotate(-(deg*2), true);
		while(pilot.isMoving()){
			curr = data.getUs().getRange();
			min=Math.min(min, curr);
			System.out.println("min: " + min);
			Color t = data.getCs1().getColor();
			if(getRealColor(t) !=-1)
				return;
		}
		
		
		pilot.rotate(deg*2, true);
		while(pilot.isMoving()) {
			curr = data.getUs().getRange();
			System.out.println("min: " + min + ",curr:" + curr);
			if( curr<= min ){
				System.out.println("Stop");
				pilot.stop();
				pilot.rotate(-10);
				found=true;
				Color t = data.getCs1().getColor();
				if(getRealColor(t) !=-1)
					return;
			}
			
		}
		
		if(!found) {
			//return original position
			pilot.rotate(-deg);
		}
	}
	
	
	public  void closeArm(Data data) {
		data.getMc().forward();
		while(!data.getMc().isStalled()) {
			// waiting to to finish operation
		}
//		data.getMc().stop();
	}
	public  void openArm(Data data) {
		data.getMc().backward();
		while(!data.getMc().isStalled()) {
			// waiting to to finish operation
		}
//		data.getMc().stop();
	}

	
	public  int getRealColor(Color c) {
		System.out.println("BLUE "+c.getBlue()+ " RED "+c.getRed()+" GREEN "+c.getGreen());
//		if(c.getBlue()<=2 && c.getRed()<=2 && c.getGreen()<=2){
//			return -1;
//		}
//		else 
//		{
//			return c.getColor();
//		}
		if(c.getBlue()>0 && c.getRed()>0 && c.getGreen()>0 &&
				(c.getBlue()> 3 || c.getRed()>3 || c.getGreen() >3)&&
				(c.getBlue()+c.getRed()+c.getGreen())/3 > 7){
			return c.getColor();
		}
		else{
			return -1;
		}
		
	}
	
	public void catchObject(Data data) {
		DifferentialPilot pilot = data.getPilot();
		boolean found = false;
		boolean cough= false;
		
		pilot.setRotateSpeed(15);
		pilot.setTravelSpeed(10);
		
		
		
		System.out.println("Look for object");
		while(!found && !cough) {
	
			alignToNearestObject(data);
			//pilot.rotate(15);
			//pilot.travel(10);
			//pilot.travel(-1);
			Color t = data.getCs1().getColor();
			
			while(pilot.isMoving() && (getRealColor(t) ==-1)){
				t = data.getCs1().getColor();
			}
			pilot.stop();
			if(getRealColor(t)>0){
				System.out.println("Found object with color:" + data.colors_list[ t.getColor()]);
				Button.waitForAnyPress();
				pilot.travel(5);
				Sound.beepSequenceUp();
				found = true;
			}
			if(!found){
				pilot.travel(-6);	
			}
			
		
			
			if(found) {
				System.out.println("Try to catch the object.");
				//turn to the found object
				pilot.rotate(-25);
				
				//try to catch object
				closeArm(data);
				System.out.println("TACHO COUNT "+data.getMc().getTachoCount());
				if (data.getMc().getTachoCount() >= data.arm_max || data.getMc().getTachoCount() <= data.arm_min){
					System.out.println("Got nothing, try again");
					Sound.beepSequence();
					cough = false;
					found = false;
					pilot.travel(-10);
					openArm(data);
					Search s=new Search();
					Catch c=new Catch();
					Goal g=new Goal();
					s.alignClosest(data, 10, false);
					c.catchObject(data);
					g.findGoal(data, 0);
				}
				else {
					System.out.println("Cought the object.");
					Sound.beepSequenceUp();
					cough = true;
				}
			}
	
	
		}
		
		
		

		
	}
	
	
}
