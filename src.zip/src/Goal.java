import lejos.nxt.Button;


public class Goal {
	public  final int RED = 0;
	public  final int BLUE = 2;
	
	
	public  void checkGoalColor(Data data, int getRed, int getBlue, String blue_or_red) {
		data.getMa().setSpeed(100);
		data.getMb().setSpeed(100);

		int curRed = getRed;
		int curBlue = getBlue;
		long currTime = System.currentTimeMillis();
		while (curRed <getRed && curBlue < getBlue  && ((System.currentTimeMillis() - currTime)/1000 < 10)) {
			data.getMa().forward();
			data.getMb().forward();
			curRed = data.getCs1().getColor().getRed();
			curBlue = data.getCs1().getColor().getBlue();
			System.out.println("getRed: "+curRed);
			System.out.println("getBlue: "+curBlue);
		}
		//Found needed color
		if ((blue_or_red.compareTo("RED")==0 && curRed >= getRed) || (blue_or_red.compareTo("BLUE")==0 && curBlue >= getBlue)) {
			System.out.println("IS NEEDED COLOR");
			data.getMc().rotate(100);
			data.getPilot().backward();
			try {
				Thread.sleep(1000);
			}
			catch (InterruptedException e) {System.out.println("exception in sleep");}
			data.getMc().rotate(-100);
			data.getPilot().rotate(-170);
			Button.waitForAnyPress();
		}
		//Didn't find needed color
		else if ((curRed < getRed && blue_or_red.compareTo("RED") ==0 ) || (curBlue < getBlue && blue_or_red.compareTo("BLUE") ==0 )){// dound the other goal, need to go to the other goal
			System.out.println("NOT NEEDED COLOR");
			data.getPilot().backward();
			try {
				Thread.sleep(2500);
			}
			catch (InterruptedException e) {System.out.println("exception in sleep");}

			data.getMa().setSpeed(250);
			data.getMb().setSpeed(250);

			data.getPilot().rotate(95);
			alignToMaxLightSource(data, 19);
			goToMaxLightSource(data, 28);
			fineTuning(data, getBlue, getRed, blue_or_red);//NOTICE IT IS OPPOSITE! getBlue and getRed switched!!

		}
		else {
			System.out.println("Prob finding goal");
			data.getPilot().travel(-30);
			fineTuning(data, getRed, getBlue, blue_or_red);
		}
	}	



	public  void fineTuning(Data data, int getRed, int getBlue, String blue_or_red) {
		System.out.println("FINE TUNE LIGHT");
		data.getMa().setSpeed(200);
		data.getMb().setSpeed(200);

		if (data.getLs().getLightValue() > 65) {
			System.out.println("LIGHT > 65, FINAL ALIGNMENT");
			data.getPilot().rotate(-50);
			alignToMaxLightSource(data, 10);
			while(data.getUs().getDistance() > 10){
				data.getPilot().forward();
				
			}
			checkGoalColor(data, getRed, getBlue, blue_or_red);
			
		}
		else {
			data.getPilot().rotate(-90);
			alignToMaxLightSource(data, 18);
			goToMaxLightSource(data, 25);
			fineTuning(data, getRed, getBlue, blue_or_red);

		}
	}



	public  void goToMaxLightSource(Data data, int distanceToCheck) {
		data.getMa().setSpeed(600);
		data.getMb().setSpeed(600);

		while (data.getUs().getDistance() > distanceToCheck) {
			data.getMa().forward();
			data.getMb().forward();
			System.out.println("speed  " + data.getMa().getSpeed());
			System.out.println("acc  " + data.getMa().getAcceleration());
		}

		if (data.getLs().getLightValue() < 63) {

			data.getPilot().rotate(-40);
			alignToMaxLightSource(data, 8);
			data.getMa().setSpeed(2000);
			data.getMb().setSpeed(2000);
			data.getMa().forward();
			data.getMb().forward();
			try {
				Thread.sleep(800);                                                         // checkkkkkk
			}
			catch (InterruptedException e) {System.out.println("exception in sleep");}

			data.getPilot().stop();
			try {
				Thread.sleep(800);                                                         
			}
			catch (InterruptedException e) {System.out.println("exception in sleep");}
			goToMaxLightSource(data, 28);

		}
		System.out.println(data.getLs().getLightValue());
	}



	public  void alignToMaxLightSource(Data data, int fieldToCheck) {
		System.out.println("ALIGN TO MAX LIGHT");
		int turnNum = 0;
		int maxLightSource = 0;

		for (int i = 0; i < fieldToCheck; i++) {
			if (data.getLs().getLightValue() > maxLightSource) {
				maxLightSource = data.getLs().getLightValue();
				turnNum = 1;
			}
			else {
				turnNum++;
			}
			data.getPilot().rotate(10);
		}
		System.out.println("Max Light:" + maxLightSource);

		data.getMa().setAcceleration(200);
		data.getMb().setAcceleration(200);
		data.getPilot().rotate(-10 * turnNum);
		data.getMa().setAcceleration(1000);
		data.getMb().setAcceleration(1000);

	}

	public  void findGoal(Data data, int colorOfGateNeeded) {
		System.out.println("LOOKING FOR GOAL");



		data.getMa().setAcceleration(1000);
		data.getMb().setAcceleration(1000);
		data.getMa().setSpeed(250);
		data.getMb().setSpeed(250);

		alignToMaxLightSource(data, 36);
		goToMaxLightSource(data, 28);
		fineTuning(data, 20,5,"RED");
	}
}
